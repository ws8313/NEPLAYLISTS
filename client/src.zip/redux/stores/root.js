import playlist from './playlist'
import {combineReducers} from 'redux'

const combinedReducer = combineReducers({
  playlist
})
export default combinedReducer
