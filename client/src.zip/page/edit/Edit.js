import React from 'react'
import Canvas from './Canvas'

export default function Edit() {

  // function dragstart_handler(e) {
  //   e.dataTransfer.setData("text/plain",e.target.id)
  // }
  
  // 엘리멘트.addEventListener("dragstart",dragstart_handler)

  // drawImage(image, canvas_x, canvas_y)

  return (
    <div>
      <Canvas />
    </div>
  )
}
