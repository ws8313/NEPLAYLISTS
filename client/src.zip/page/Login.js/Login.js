import React from 'react'
import ReactLoading from 'react-loading'


export default function Login() {
  return (
    <div>

     <ReactLoading  
     
     style={{

      width: '100px',
      height: '100px'
    }}
     ></ReactLoading>
      
    </div>
  )
}
